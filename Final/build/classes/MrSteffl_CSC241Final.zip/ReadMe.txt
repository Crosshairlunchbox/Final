=======================================
Mr. Chad Steffl, S02269293
CSC 241 Final Project
12/11/16
V 1.2

=======================================

\\util\OutputData file must be updated
prior to first use to initialize the 
save/load directory.


Update line 31 to the location of util
folder.

I.E.
C:\users\public\documents\util\CharData.txt


Should be entered as 
new File("C:\\users\\public\\documents\\util\\CharData.txt");



CharData does NOT need to be created.
Once the program is run it will 
create the necessary file.

=========================